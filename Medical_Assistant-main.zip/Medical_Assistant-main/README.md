# Medical_Assistant

Using **Whisper.ai**, LLMs for summarization and **RAG** (Retival Augmented Generation)
